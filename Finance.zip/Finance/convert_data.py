import json

def convert_to_json():
    """
    Reads the specially formatted test.txt file and directly converts the
    labeled relationships into the relations.json format.
    """
    print("🚀 Starting direct conversion of labeled data...")
    extracted_relations = []
    
    try:
        with open('test.txt', 'r', encoding='utf-8') as f:
            for line in f:
                if '|' not in line:
                    continue
                
                parts = line.split('|', 1)
                if len(parts) < 2:
                    continue

                relations_part = parts[1]
                individual_relations = relations_part.split('|')
                
                for rel_text in individual_relations:
                    triplet_parts = [p.strip() for p in rel_text.split(';')]
                    
                    if len(triplet_parts) == 3:
                        subject, obj, relation = triplet_parts
                        extracted_relations.append((subject, obj, relation))

    except FileNotFoundError:
        print("❌ ERROR: test.txt not found.")
        return

    unique_relations = list(set(extracted_relations))
    print(f"✅ Conversion complete. Found {len(unique_relations)} unique relationships.")

    with open('relations.json', 'w', encoding='utf-8') as f:
        json.dump(unique_relations, f, indent=4)
    print("💾 Knowledge base 'relations.json' has been created. You can now run the app.py server.")


if __name__ == '__main__':
    convert_to_json()